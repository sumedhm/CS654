<?php

$vip = "localhost";
$con = mysqli_connect($vip, "root", "root", "trial_db");
$user=0;
$err = 'Not logged in.';

if(isset($_COOKIE['log'])){
	$logged_in = $_COOKIE['log'];
	$user = $_COOKIE['user'];
} else {
	header("Location: login.php?err=".$err);
}


$res = mysqli_query($con, "SELECT * FROM users where id=".$user);
$row = mysqli_fetch_array($res);
$username = $row['username'];
$pass = $row['password'];

echo "<h4>Profile Info</h4>";

$hash = SHA1($username).SHA1($pass);
if($hash==$logged_in){
	echo "<table>";
	echo "<form action='update.php' method='post'>
	<input type='hidden' name='id' value='".$row['id']."'>
	<tr><td>Username</td><td><input type='text' disabled value='".$row['username']."'></td></tr>
	<tr><td>Name</td><td><input type='text' name='name' value='".$row['name']."'></td></tr>
	<tr><td>Email</td><td><input type='text' name='email' value='".$row['email']."'></td></tr>
	<tr><td>Bdate</td><td><input type='text' name='bdate' value='".$row['bdate']."'></td></tr>
	<tr><td>Contact</td><td><input type='text' name='contact' value='".$row['contact']."'></td></tr>
	</table>
	<input type='submit' value='Update'>
	</form> <a href='logout.php'><button>Log Out</button></a>";
} else {
	header("Location: login.php?err=".$err);
}
mysqli_close($con);

echo "<br><br><br><br>--------------------------------------<br><small>Served by Omega</small>";

?>
