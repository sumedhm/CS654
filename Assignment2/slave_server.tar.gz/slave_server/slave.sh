#!/bin/bash
echo "begin ping"
((flag = 1))
while [[ 1 ]] ; do
	if [[ flag -eq 1 ]] ; then
		sleep 1
		ping -c 1 10.42.0.88
        	rc=$?
        	if [[ $rc -ne 0 ]] ; then
        	        ((flag=0))
			echo "The main server is down."
			ifconfig eth0:1 10.42.0.80 netmask 255.255.255.0
			arping -q -U -c 3 -I eth0 10.42.0.80
			echo "VIP changed."
	        fi
	fi
	if [[ flag -eq 0 ]] ; then
		sleep 1
		ping -c 1 10.42.0.88
        	rc=$?
		if [[ $rc -eq 0 ]] ; then
        	        ((flag=1))
			echo "The main server is up again."
			mysqldump -u root --password=root trial_db > ~/trial_db.sql
			#give any false virtual ip.
			ifconfig eth0:1 10.42.0.250 netmask 255.255.255.0
			arping -q -U -c 3 -I eth0 10.42.0.250
			echo "VIP changed."
	        fi
	fi		
        
done

