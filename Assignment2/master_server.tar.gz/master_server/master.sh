#!bin/bash

while [[ 1 ]] ; do
        ssh -q omega@10.42.0.68 [[ -f ./trial_db.sql ]] && break;
        sleep 1
done
scp omega@10.42.0.68:./trial_db.sql ~/.
ssh -q omega@10.42.0.68 << ENDHERE
	rm ~/trial_db.sql
	exit
ENDHERE
mysql -u root --password=root trial_db < trial_db.sql
ifconfig eth0:vip 10.42.0.80 netmask 255.255.255.0
arping -q -U -c 3 -I eth0 10.42.0.80
