<?php
date_default_timezone_set("Asia/Kolkata");
echo date("l, F d, Y, h:i:s A");

echo "<br><br><br><br><br>------------------------------------------
<br>Served by Sentinel.";

?>
