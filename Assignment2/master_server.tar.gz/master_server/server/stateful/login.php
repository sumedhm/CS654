

<html>
<body>

<h4>Log In</h4>

<?php
	if(isset($_GET['err'])){
		echo "<br>
		<span style='color:red'>".$_GET['err']."</span>
		<br>";
	}
?>

<form action='createsession.php' method='POST'>
<table>
<tr>
<td>Username</td><td><input type='text' name='username'></td>
</tr>
<tr>
<td>Password</td><td><input type='password' name='password'></td>
</tr>
</table>
<input type='submit' value='Log In'>
</form>
<br><br><br><br><br>------------------------------------------------<br><small>Served by Sentinel</small>
</body>
</html>
