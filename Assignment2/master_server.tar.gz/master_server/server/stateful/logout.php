<?php

setcookie("log","",time()-3600,'/');
header("Location: stateful.php");

?>
