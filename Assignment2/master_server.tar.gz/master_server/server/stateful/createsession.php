<?php

$vip = "localhost";
$con = mysqli_connect($vip, "root", "root", "trial_db");
$id=0;
$err = "Not logged in.";
        $u = $_POST['username'];
        $p = $_POST['password'];
        $err = "Wrong username/password.";
        $res = mysqli_query($con, "SELECT * from users where username='".$u."'");
        $hash = SHA1($u).SHA1($p);
        $row = mysqli_fetch_array($res);
        $id = $row['id'];
        setcookie("log",$hash,0);
        setcookie("user",$id,0);
        header("Location: stateful.php");
mysqli_close($con);
?>
