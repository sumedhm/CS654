<?php

$name = $_POST['name'];
$email = $_POST['email'];
$bdate = $_POST['bdate'];
$contact = $_POST['contact'];

$con = mysqli_connect("localhost","root","root","trial_db");

$query = mysqli_query($con, "UPDATE users set name='".$name."',email='".$email."',bdate='".$bdate."',contact='".$contact."' where id=".$_POST['id']);

mysqli_close($con);
header("Location: stateful.php");
?>
